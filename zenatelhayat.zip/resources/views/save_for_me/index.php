
SELECT SUM(amount_before_discount)
FROM appointments
WHERE patient_id=1;
-------

//for me
