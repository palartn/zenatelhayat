
<?php $__env->startSection('content'); ?>
<div id="kt_content_container" class="container-xxl mt-6">
<div class="card card-flush h-lg-100" id="kt_contacts_main">
	<!--begin::Card header-->
	<div class="card-header pt-7" id="kt_chat_contacts_header">
		<!--begin::Card title-->
		<div class="card-title">
			<!--begin::Svg Icon | path: icons/duotune/communication/com005.svg-->
			<span class="svg-icon svg-icon-1 me-2">
				<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M20 14H18V10H20C20.6 10 21 10.4 21 11V13C21 13.6 20.6 14 20 14ZM21 19V17C21 16.4 20.6 16 20 16H18V20H20C20.6 20 21 19.6 21 19ZM21 7V5C21 4.4 20.6 4 20 4H18V8H20C20.6 8 21 7.6 21 7Z" fill="currentColor"></path>
					<path opacity="0.3" d="M17 22H3C2.4 22 2 21.6 2 21V3C2 2.4 2.4 2 3 2H17C17.6 2 18 2.4 18 3V21C18 21.6 17.6 22 17 22ZM10 7C8.9 7 8 7.9 8 9C8 10.1 8.9 11 10 11C11.1 11 12 10.1 12 9C12 7.9 11.1 7 10 7ZM13.3 16C14 16 14.5 15.3 14.3 14.7C13.7 13.2 12 12 10.1 12C8.10001 12 6.49999 13.1 5.89999 14.7C5.59999 15.3 6.19999 16 7.39999 16H13.3Z" fill="currentColor"></path>
				</svg>
			</span>
			<!--end::Svg Icon-->
			<h2 >تعديل بيانات مريض</h2>
		</div>
		<!--end::Card title-->
	</div>

	

    



	<div class="card-body pt-5">
	<!--begin::Form-->
		<form method="POST" action="<?php echo e(route('patients.update',$patient->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
			<?php echo method_field('put'); ?>
           <div class="row ">
                <div class="col xl-3">
					<label class="fs-4 fw-semibold form-label" for="patient_sname"> إسم الأول</label>
                  <input type="text" id="patient_fname" class="form-control form-control-solid <?php $__errorArgs = ['patient_fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="patient_fname"  value="<?php echo e($patient->patient_fname); ?>" placeholder="الإسم الأول" required>
                  <?php $__errorArgs = ['patient_fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="col xl-3">
                <label class="fs-4 fw-semibold form-label" for="patient_sname"> إسم الأب</label>
                  <input type="text" id="patient_sname" class="form-control form-control-solid <?php $__errorArgs = ['patient_sname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="patient_sname"  value="<?php echo e($patient->patient_sname); ?>" placeholder="إسم الأب" required  >
                  <?php $__errorArgs = ['patient_sname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col xl-3">
					<label class="fs-4 fw-semibold form-label" for="patient_sname"> إسم الجد</label>
                  <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['patient_tname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="patient_tname"  value="<?php echo e($patient->patient_tname); ?>" placeholder="إسم الجد" >
                </div>
                <div class="col xl-3">
					<label class="fs-4 fw-semibold form-label" for="patient_lname"> إسم العائلة</label>
                  <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['patient_lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="patient_lname"  value="<?php echo e($patient->patient_lname); ?>" placeholder="إسم العائلة" required >
                  <?php $__errorArgs = ['patient_lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
             </div>

			 <div class="row mt-6">
			 <div class="col xl-3">
				<label class="fs-4 fw-semibold form-label" for="idc"> رقم الهوية</label>
			  <input type="number" class="form-control form-control-solid <?php $__errorArgs = ['idc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="idc"  value="<?php echo e($patient->idc); ?>" placeholder="رقم الهوية" required>
              <?php $__errorArgs = ['idc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="col xl-3">
				<label class="fs-4 fw-semibold form-label" for="patient_dob"> تاريخ الميلاد</label>
			  <input id="kt_datepicker_5" type="text" class="form-control form-control-solid ps-12 flatpickr-input active <?php $__errorArgs = ['patient_dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="patient_dob"  value="<?php echo e($patient->patient_dob); ?>" placeholder="تاريخ الميلاد" >
			  
			</div>

			<div class="col xl-3">
				<label class="fs-4 fw-semibold form-label" for="occupation"> الوظيفة</label>
			  <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="occupation"  value="<?php echo e($patient->occupation); ?>" placeholder="الوظيفة" >
			</div>



		<div class="row mt-6">
			<div class="col xl-3">
			   <label class="fs-4 fw-semibold form-label" for="email"> البريد الإلكتروني</label>
			 <input type="email" class="form-control form-control-solid <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"  value="<?php echo e($patient->email); ?>" placeholder="البريد الإلكتروني" >
		   </div>
		   <div class="col xl-3">
			   <label class="fs-4 fw-semibold form-label" for="mobile"> جوال</label>
			 <input type="number" class="form-control form-control-solid  <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="mobile"  value="<?php echo e($patient->mobile); ?>" placeholder="جـــوال" >
             <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

		   </div>

		   <div class="col xl-3">
			   <label class="fs-4 fw-semibold form-label" for="mobile_second"> جوال أخر</label>
			 <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['mobile_second'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile_second"  value="<?php echo e($patient->mobile_second); ?>" placeholder="جوال ثاني إن وجد" >
		   </div>
	   	   </div>

	   <div class="row mt-6">
		<div class="col xl-3">
		   <label class="fs-4 fw-semibold form-label" for="address"> العنوان</label>
		 <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address"  value="<?php echo e($patient->address); ?>" placeholder="عنوان السكن" >
	   </div>

	   <div class="col xl-3">
		<label class="fs-4 fw-semibold form-label">
			<span>الجنس</span>
			<i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Enter the contact's phone number (optional)." data-kt-initialized="1"></i>
		</label>
		<!--end::Label-->
		<!--begin::Input-->
		<select name="gender" class="form-select" data-control="select2" data-placeholder="الرجاء الإختيار">

			<option value ="Male" <?php echo e($patient->gender == "Male" ? 'selected' : ''); ?>>ذكر</option>
            <option value ="Female" <?php echo e($patient->gender == "Female" ? 'selected' : ''); ?>>أنثى</option>
		</select>
		 
	   </div>
	</div>

	<hr style="height:2px;border-width:0;color:gray;background-color:#dcd9d9">


	<div class="row mt-6">
			<div class="col xl-3">
			   <label class="fs-4 fw-semibold form-label" for="husband_name"> إسم الزوج/ة</label>
			 <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['husband_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="husband_name"  value="<?php echo e($patient->husband_name); ?>" placeholder=" إسم الزوج / الزوجة" >
		   </div>
		   <div class="col xl-3">
			   <label class="fs-4 fw-semibold form-label" for="mobile"> عمل الزوج/ة</label>
			 <input type="text" class="form-control form-control-solid  <?php $__errorArgs = ['husband_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="husband_occupation"  value="<?php echo e($patient->husband_occupation); ?>" placeholder="عمل الزوج / الزوجة" >
			 
		   </div>

		
			<div class="col xl-3">
				<label class="fs-4 fw-semibold form-label" for="husband_dob"> تاريخ الميلاد</label>
			  <input id="husband_dob" type="text" class="form-control form-control-solid ps-12 flatpickr-input active <?php $__errorArgs = ['husband_dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="husband_dob"  value="<?php echo e($patient->husband_dob); ?>" placeholder="تاريخ الميلاد" >
			</div>
	   	   </div>

		<div class="d-flex flex-column mb-8 mt-6">
			<label class="fs-4 fw-semibold form-label">ملاحظـــات</label>
			<textarea class="form-control form-control-solid" rows="3" name="notes" placeholder="ملاحظات" ><?php echo e($patient->notes); ?></textarea>
		</div>
		<div class="d-flex">

				<button type="submit" id="btn" class="btn btn-primary">
				<span class="indicator-label btn-lg btn-block">حفظ</span>
				</button>

</form>
 </div>
</div>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('scripts'); ?>
<script>setTimeout(function() {
	$('.alert-session-flash').fadeOut('low');
}, 3000); // <-- time in milliseconds
</script>
<script>

$(".flatpickr-input").flatpickr({

});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zenatelhayat\resources\views/patient/edit.blade.php ENDPATH**/ ?>